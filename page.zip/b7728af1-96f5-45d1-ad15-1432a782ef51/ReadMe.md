Crunchy Munchkins Website
 About the Project
A simple, responsive web page for Crunchy Munchkins which a snack brand. It includes a header, navigation menu, product description, and footer.

Design Choices
Colors: Light blue for background and dark blue for navigation bar. On hover, links change to bright pink text.
Font family : Times New Roman for a friendly look.
Font size: Centered content with 20px body text and a large header for the brand name.
Responsive: Media queries ensure that on smaller screen, the navigation links become block elements for mobile.
Layout: header- brand name is centered 
    Navigation - horizontal links on desktop and vertical on small screens.
Main content - paragraphs for product description with good spacing.

How to View the project 
 Open the .html file in any browser like  chrome Or paste the code into  any online HTML editor.